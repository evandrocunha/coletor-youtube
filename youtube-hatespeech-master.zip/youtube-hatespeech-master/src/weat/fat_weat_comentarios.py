from gensim import corpora, models, similarities
import json
import numpy
import random
import csv
import itertools
import gensim, copy
from collections import defaultdict

target_words = {}
attribute_words= {}

target_words["math"] = [ "math", "algebra", "geometry", "calculus", "equations","computation", "numbers", "addition"]


# WEAT 1 Flowers
target_words["1_a"] = ["aster", "clover", "hyacinth", "marigold", "poppy","azalea","crocus", "iris", "orchid", "rose", "bluebell", "daffodil", "lilac", "pansy",
                           "tulip", "buttercup", "daisy", "lily", "peony", "violet", "carnation", "gladiola", "magnolia","petunia", "zinnia"]
target_words["1_b"]  = ["ant", "caterpillar", "flea", "locust", "spider","bedbug", "centipede", "fly", "maggot", "tarantula", "bee", "cockroach", "gnat",
                           "mosquito", "termite","beetle", "cricket", "hornet", "moth", "wasp", "blackfly", "dragonfly", "horsefly", "roach", "weevil"]
attribute_words["1_a"]  = [ "caress", "freedom", "health", "love", "peace", "cheer", "friend", "heaven", "loyal", "pleasure", "diamond",
                                 "gentle", "honest", "lucky", "rainbow", "diploma", "gift", "honor", "miracle", "sunrise", "family", "happy",
                                 "laughter", "paradise", "vacation"]
attribute_words["1_b"]  = ["abuse", "crash", "filth", "murder", "sickness", "accident", "death", "grief", "poison", "stink", "assault", "disaster", "hatred",
                                  "pollute", "tragedy", "divorce", "jail", "poverty", "ugly", "cancer", "kill", "rotten", "vomit", "agony", "prison"]
# WEAT 2 Carrer Family
target_words["2_a"]  = ["john","paul","mike","kevin","steve","greg","jeff", "bill"]
target_words["2_b"]  =    ["amy","joan","lisa","sarah","diana","kate","ann", "donna"]
attribute_words["2_a"]  = ["executive","management","professional","corporation","salary","office","business", "career" ]
attribute_words["2_b"]  = ["home","parents","children","family","cousins","marriage","wedding", "relatives" ]




# WEAT 3 science arts
target_words["3_a"] = [ "science", "technology", "physics", "chemistry",
        "einstein", "nasa", "experiment", "astronomy"]
target_words["3_b"] = ["poetry", "art", "shakespeare", "dance", "literature", "novel", "symphony", "drama"]
attribute_words["3_a"]  = ["brother", "father", "uncle", "grandfather","son","he", "his", "him"]
attribute_words["3_b"] =    ["sister", "mother", "aunt", "grandmother", "daughter", "she", "hers", "her"]


# WEAT 4  math arts male_female
target_words["4_a"]  = ["math","algebra","geometry","calculus","equations","computation","numbers" ]
target_words["4_b"]  = ["poetry","art","dance","literature","novel","symphony","drama","sculpture" ]
attribute_words["4_a"]  = ["male","man","boy","brother","he","him","his", "son"]
attribute_words["4_b"]  = ["female","woman","girl","sister","she","her","hers", "daughter"]




# WEAT 5 SEXUALIDADE
target_words["5_a"] = [ "straight", "heterosexual"]
target_words["5_b"] = ["gay", "homosexual", "lesbians"]
attribute_words["5_a"]  = ["terrific", "excitement", "fantastic",
        "fabulous", "pleasure", "happy", "glad", "delightful"]
attribute_words["5_b"] =    ["despise", "angry", "failure", "awful", "hatred",
        "scorn","hurtful", "sadness"]

# WEAT 6 Eur. vs Afr.
target_words["6_a"]  = ["adam","chip","harry","josh","roger","alan","frank",
        "ian", "justin", "ryan", "andrew", "fred", "jack", "matthey", "stephen",
        "brad", "greg", "jed", "paul", "todd",  "brandon", "hank",
        "jonathan","peter", "wilbur", "amanda", "courtney", "heather",
        "melanie", "sara", "amber", "crystal", "katie", "meredith", "shannon",
        "betsy", "donna", "kristin",  "nancy", "stephanie", "ellen", "lauren",
        "peggy", "collen", "emily", "megan", "rachel", "wendy" ]
target_words["6_b"]  = ["alonzo","jamel","lerone","percell","theo","alphonse","jerome", "leroy",
        "rasaan", "torrance", "darnell", "lamar", "lionel", "rashaun",  "tyree",
        "deion","lamont","malik","terrance", "tyrone", "lavon",
        "marcellus", "wardell",  "aiesha", "lashelle", "nichelle",
        "shereen","temeka", "ebony", "latisha", "shaniqua", "tameisha",
         "jasmine", "latonya", "shanise", "tanisha", "tia","lakisha",
        "latoya", "sharise","tashika","yolanda",
        "malika", "tawanda", "yvette"]
attribute_words["6_a"]  = ["caress","freedom","health","love","peace","cheer","friend", "heaven","loyal","pleasure","diamond","gentle","honest","lucky","rainbow","diploma","gift","honor","miracle","sunrise","family","happy",
                                "laughter","paradise","vacation"]
attribute_words["6_b"]  = ["abuse","crash","filth","murder","sickness","accident","death","grief","poison","stink", "assault", "disaster", "hatred", "pollute", "tragedy", "bomb","divorce", "jail", "poverty", "ugly", "cancer",
                                    "evil", "kill", "rotten", "vomit"]

# 7 WEAT RELIGAO
# Religious  Judaism Christianity
target_words["7_a"]  = ["church","bible","christian","christianity"]
target_words["7_b"]  = ["synagogue","torah","jew","judaism"]
attribute_words["7_a"]  = ["terrific","delight","celebrate","glad","beautiful","appealing", "pleasure", "enjoy" ]
attribute_words["7_b"]  = ["hate","angry","detest","despise","dirty","humiliate","pain", "horrible"]


# 8 WEAT RELIGAO
# Religious arab muslims / other people
target_words["8_a"]  = ["ernesto","matthais","maarten","philippe","guillame","benoit","takuya","kazuki","chaiyo","marcelo"]
target_words["8_b"]  = ["hakim","sharif","yousef","wahib","akbar","muhsin","salim","karim","habib","ashraf"]
attribute_words["8_a"]  = ["fantastic","cherish","adore","delight","joyous","cheerful", "enjoy", "glorious" ]
attribute_words["8_b"]  = ["yucky","tragic","abuse","hatred","negative","disaster","horrible", "despise"]

# 9 WEAT RELIGAO
# Religious   islam / judaism
target_words["9_a"]  = ["synagogue","torah","jew","judaism"]
target_words["9_b"]  = ["mosaque","koran","muslim","islam"]
attribute_words["9_a"]  = ["fantastic","adore","enjoy","cheerful","celebrate","friend", "cherish", "excitement" ]
attribute_words["9_b"]  = ["selfish","yucky","failure","pain","poison","annoy","ugly", "gross"]






def statistic_test(X,Y,A,B,M):
    result = 0.0
    sum_X = 0.0
    sum_Y = 0.0

    for word_X in X:
        sum_X += sub_statistic_test(word_X, A,B,M)
    for word_Y in Y:
        sum_Y += sub_statistic_test(word_Y, A,B,M)

    return (sum_X - sum_Y)

def sub_statistic_test(w,A,B,M):
    result = 0.0
    sum_cos_A = 0.0
    sum_cos_B = 0.0

    for word_A in A:
        sum_cos_A += numpy.dot(M[w],M[word_A])/(numpy.linalg.norm(M[w])*numpy.linalg.norm(M[word_A]))
    for word_B in B:
        sum_cos_B += numpy.dot(M[w],M[word_B])/(numpy.linalg.norm(M[w])*numpy.linalg.norm(M[word_B]))

    return (sum_cos_A/len(A) - sum_cos_B/len(B))

def effect_size(x_words,y_words,a_attributes,b_attributes,M):
    # Effect size
    test_x = 0.0
    test_y = 0.0
    samples = []

    for word_x in target_words[x_words]:
        test_x += sub_statistic_test(word_x,attribute_words[a_attributes],attribute_words[b_attributes],M)
        samples.append(sub_statistic_test(word_x,attribute_words[a_attributes],attribute_words[b_attributes],M))

    for word_y in target_words[y_words]:
        test_y += sub_statistic_test(word_y,attribute_words[a_attributes],attribute_words[b_attributes],M)
        samples.append(sub_statistic_test(word_y,attribute_words[a_attributes],attribute_words[b_attributes],M))

    mean_x =  test_x/len(target_words[x_words])
    mean_y =  test_y/len(target_words[y_words])

    #print("mean_x = " + str(mean_x))
    #print("mean_y = " + str(mean_y))
    std_dev = numpy.std(samples)
    #print("std-dev = " + str(std_dev))
    effect_size =  (mean_x - mean_y)/std_dev
    return effect_size


# Calcula o P-Value
def p_value(X,Y,A,B,model):
    null_hipotese_evidance = 0.0
    number_permitations = 0.0

    # Encontra o maior set possivel de memso tamanho das duas classes
    X_size =  len(target_words[X])
    Y_size =  len(target_words[Y])
    size = max(X_size, Y_size)
    union = set(target_words[X] + target_words[Y])
    random_test_statistic_values = []
    test_statistic_value = statistic_test(target_words[X],target_words[Y],attribute_words[A],attribute_words[B],model)
    #
    #print("Size e: " + str(size))
    if (Y_size + X_size) < 14:
        # there will be less than 5000 combinations
        permutations = itertools.combinations(union,size)

        for i,permutation in enumerate(permutations):
            x_i = permutation
            y_i = union - set(permutation)
            test_value = statistic_test(x_i,y_i,attribute_words[A],attribute_words[B],model)
            # save the valus to be used for each channel
            random_test_statistic_values.append(test_value)
            if( test_value > test_statistic_value):
                null_hipotese_evidance += 1
            number_permitations += 1

        #print("null hipotese_evidance: " + str(null_hipotese_evidance))
        #print("num_permutations: " + str(number_permitations))
        #print("P-Value():")
        #print(null_hipotese_evidance/number_permitations)
        p_value_result =  null_hipotese_evidance/number_permitations
        #print("enviando " + str(p_value_result))
        return(p_value_result)

    else:
        # There will be more than 5000, then we should randomize
        print("Gerando 5000 aleatorios")
        classes = target_words[X] + target_words[Y]

        for i in range(5000):
          random.shuffle(classes)
          x_i = classes[:size]
          y_i = classes[size+1:]
          test_value = statistic_test(x_i,y_i,attribute_words[A],attribute_words[B],model)
          # save the valus to be used for each channel
          random_test_statistic_values.append(test_value)
          if( test_value > test_statistic_value):
            null_hipotese_evidance += 1
          number_permitations += 1
          #if number_permitations % 100 == 0:
          #    print(number_permitations)

        #print("null hipotese_evidance: " + str(null_hipotese_evidance))
        #print("num_permutations: " + str(number_permitations))
        #print("P-Value(english):")
        #print(null_hipotese_evidance/number_permitations)
        p_value_result =  null_hipotese_evidance/number_permitations
        #print("enviando " + str(p_value_result))
        return(p_value_result)


##################################################### CALCULA ##############333


channels = {}

# Procura saber quais channels existem
for line in open("../../data/videos-filtered.jsonl"):
  data = json.loads(line)
  current_channel = data["channel_id"]
  channels[current_channel] = ""

# Vetor com quais testes eram realizados
testes = [1,2,3,4,5,6,7,8,9]
#testes = [5]
results = []

with open("./weat_results_comentarios.csv", "w") as csvfile:
    writer = csv.writer(csvfile, delimiter=',')

    # Itera sobre os channels
    for channel in channels:
    #for channel in ["UC_gE-kg7JvuwCNlbZ1-shlA"]:
        print(channel)
        model = gensim.models.Word2Vec.load("./modelos/"+channel+"_comments")
        print("carreguei")
        result = str(channel)

        for teste in testes:
            X =  str(teste) + "_a"
            Y =  str(teste) + "_b"
            A =  str(teste) + "_a"
            B =  str(teste) + "_b"
            ##  Effect size of the base model
            effect_size_result =  effect_size(X,Y,A,B,model)
            print("Effect-Size("+str(teste)+ "):" + str(effect_size_result))
            p_value_result  =  p_value(X,Y,A,B,model)
            print("P-value("+str(teste)+ "):" + str(p_value_result))
            result = result +  "," + str(effect_size_result) + "," + str(p_value_result)

        print(result)
        writer.writerow(result.split(","))
        #results.append(result.split(","))



#print(results)
# Escreve o csv
#with open("./weat_results.csv", "w") as csvfile:
#    writer = csv.writer(csvfile, delimiter=',')
#    for result in results:
#        writer.writerow(result)






#Effect size:
#X = "1_flowers"
#Y = "1_insects"
#A = "1_pleasant"
#B = "1_unpleasant"
#
#print("Test:" + X + "_"+ Y + " X " + A + "_" + B)
#
##  Effect size of the base model
#print("Effect-Size:" + str(effect_size(X,Y,A,B,model)))
#
## build the permutation test values of all or of the sample (if more than 14
## word classes)
###P-value
#null_hipotese_evidance = 0.0
#number_permitations = 0.0
## Encontra o maior set possivel de memso tamanho das duas classes
#X_size =  len(target_words[X])
#Y_size =  len(target_words[Y])
#size = max(X_size, Y_size)
#union = set(target_words[X] + target_words[Y])
#random_test_statistic_values = []
#test_statistic_value = statistic_test(target_words[X],target_words[Y],attribute_words[A],attribute_words[B],model)
#
#print("Size e: " + str(size))
#if (Y_size + X_size) < 14:
#    # there will be less than 5000 combinations
#    permutations = itertools.combinations(union,size)
#
#    for i,permutation in enumerate(permutations):
#        x_i = permutation
#        y_i = union - set(permutation)
#        test_value = statistic_test(x_i,y_i,attribute_words[A],attribute_words[B],model)
#        # save the valus to be used for each channel
#        random_test_statistic_values.append(test_value)
#        if( test_value > test_statistic_value):
#            null_hipotese_evidance += 1
#        number_permitations += 1
#
#    print("null hipotese_evidance: " + str(null_hipotese_evidance))
#    print("num_permutations: " + str(number_permitations))
#    print("P-Value(english):")
#    print(null_hipotese_evidance/number_permitations)
#
#else:
#    # There will be more than 5000, then we should randomize
#    print("Gerando 5000 aleatorios")
#    classes = target_words[X] + target_words[Y]
#
#    for i in range(5000):
#      random.shuffle(classes)
#      x_i = classes[:size]
#      y_i = classes[size+1:]
#      test_value = statistic_test(x_i,y_i,attribute_words[A],attribute_words[B],model)
#      # save the valus to be used for each channel
#      random_test_statistic_values.append(test_value)
#      if( test_value > test_statistic_value):
#        null_hipotese_evidance += 1
#      number_permitations += 1
#      #if number_permitations % 100 == 0:
#      #    print(number_permitations)
#
#    print("null hipotese_evidance: " + str(null_hipotese_evidance))
#    print("num_permutations: " + str(number_permitations))
#    print("P-Value(english):")
#    print(null_hipotese_evidance/number_permitations)
#
#
## for each channel print the change in the woman vector:
#for channel_id in channels_transcripts:
#    if channel_id != "all":
#
#        # Train the model
#        model_wiki = copy.deepcopy(model)
#        model_wiki.train(channels_transcripts[channel_id],total_examples=model.corpus_count,epochs=model.iter)
#        print("Effect-Size(" + str(channel_id) +":" + str(effect_size(X,Y,A,B,model_wiki)))
#
#        ##P-value
#        test_statistic_value = statistic_test(target_words[X],target_words[Y],attribute_words[A],attribute_words[B],model_wiki)
#        # Count in favor of the null hipoteses
#        null_hipotese_evidance = 0.0
#
#        if  random_test_statistic_values:
#            for value in  random_test_statistic_values:
#                if value > test_statistic_value:
#                    null_hipotese_evidance += 1
#        print("null hipotese_evidance: " + str(null_hipotese_evidance))
#        print("num_permutations: " + str(len(random_test_statistic_values)))
#        print("P-Value("+ str(channel_id) +  "):")
#        print(null_hipotese_evidance/len(random_test_statistic_values))







#cosine_similarity_prostitute = numpy.dot(model['woman'],model['prostitute'])/(numpy.linalg.norm(model['woman'])*numpy.linalg.norm(model['prostitute']))
#cosine_similarity_seductress =  numpy.dot(model['woman'],model['seductress'])/(numpy.linalg.norm(model['woman'])*numpy.linalg.norm(model['seductress']))
#print(cosine_similarity_prostitute,cosine_similarity_seductress)
#print(model.most_similar("woman"))
#antes = copy.deepcopy(model.wv["woman"])




