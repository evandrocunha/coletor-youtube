from gensim import corpora, models, similarities
import json
import numpy
import random
import itertools
import gensim, copy
from collections import defaultdict

target_words = {}
attribute_words= {}

target_words["math"] = [ "math", "algebra", "geometry", "calculus", "equations","computation", "numbers", "addition"]


# WEAT 1 Flowers
target_words["flowers_1"] = ["aster", "clover", "hyacinth", "marigold", "poppy","azalea","crocus", "iris", "orchid", "rose", "bluebell", "daffodil", "lilac", "pansy",
                           "tulip", "buttercup", "daisy", "lily", "peony", "violet", "carnation", "gladiola", "magnolia","petunia", "zinnia"]
target_words["insects_1"]  = ["ant", "caterpillar", "flea", "locust", "spider","bedbug", "centipede", "fly", "maggot", "tarantula", "bee", "cockroach", "gnat",
                           "mosquito", "termite","beetle", "cricket", "hornet", "moth", "wasp", "blackfly", "dragonfly", "horsefly", "roach", "weevil"]
attribute_words["pleasant_1"]  = [ "caress", "freedom", "health", "love", "peace", "cheer", "friend", "heaven", "loyal", "pleasure", "diamond",
                                 "gentle", "honest", "lucky", "rainbow", "diploma", "gift", "honor", "miracle", "sunrise", "family", "happy",
                                 "laughter", "paradise", "vacation"]
attribute_words["unpleasant_1"]  = ["abuse", "crash", "filth", "murder", "sickness", "accident", "death", "grief", "poison", "stink", "assault", "disaster", "hatred",
                                  "pollute", "tragedy", "divorce", "jail", "poverty", "ugly", "cancer", "kill", "rotten", "vomit", "agony", "prison"]



# WEAT 8
target_words["science_8"] = [ "science", "technology", "physics", "chemistry",
        "einstein", "nasa", "experiment", "astronomy"]
target_words["arts_8"] = ["poetry", "art", "shakespeare", "dance", "literature", "novel", "symphony", "drama"]
attribute_words["male_terms_8"]  = ["brother", "father", "uncle", "grandfather","son","he", "his", "him"]
attribute_words["female_terms_8"] =    ["sister", "mother", "aunt", "grandmother", "daughter", "she", "hers", "her"]

# WEAT 9 SEXUALIDADE
target_words["straight_9"] = [ "straight", "heterosexual"]
target_words["homo_9"] = ["gay", "homosexual", "lesbians"]
attribute_words["good_9"]  = ["terrific", "excitement", "fantastic",
        "fabulous", "pleasure", "happy", "glad", "delightful"]
attribute_words["bad_9"] =    ["despise", "angry", "failure", "awful", "hatred",
        "scorn","hurtful", "sadness"]

# WEAT 10 Mental Disease
target_words["mental_10"] = [ "sad",
        "hopeless","gloomy","tearful","miserable","depressed"]
target_words["physical_disease_10"] = ["sick", "illness", "influenza",
        "disease", "virus", "cancer"]
attribute_words["temporary_10"]  = ["impermanent", "unstable", "variable",
        "fleeting", "short", "brief", "occasional"]
attribute_words["permanent_10"] =    ["stable", "always", "constant",
        "persistent", "chronic",
        "prolonged","forever"]

# WEAT 11 young and old
target_words["young_11"] = [
        "tiffany","michelle","cindy","kristy","brad","eric","joey","billy"]
target_words["old_11"] = ["ethel", "bernice", "gertrude",
        "agnes", "cecil", "wilbert","mortimer","edgar"]
attribute_words["pleasant_11"]  = ["joy", "love", "peace",
        "wonderful", "pleasure", "friend", "laughter","happy"]
attribute_words["unpleasant_11"] =    ["agony", "terrible", "horrible",
        "nasty", "evil",
        "war","awful","failure"]





target_words["instruments"]  = ["bagpipe","cello","guitar","lute","trombone","banjo","clarinet", "harmonica","mandolin", "trumpet","bassoon","drum","harp","oboe","tuba","bell","fiddle","harpsichord","piano","viola","bongo","flute","horn","saxophone","violin"]
target_words["weapons"]  = ["arrow","club","gun","missile","spear","axe","dagger", "harpoon","pistol","sword","blade","dynamite","hatchet","rifle","tank","bomb","firearm","knife","shotgun","teargas","cannon","grenade","mace","slingshot","whip"]
target_words["eur_americans"]  = ["adam", "chip", "harry", "josh", "roger", "alan", "frank", "ian", "justin", "ryan", "andrew", "fred", "jack", "matthew", "stephen", "brad", "greg", "jed", "paul", "todd", "brandon", "hank", "jonathan", "peter", "wilbur", "amanda", "courtney", "heather", "melanie", "sara", "amber", "crystal", "katie", "meredith", "shannon", "betsy", "donna", "kristin", "nancy", "stephanie", "ellen", "lauren", "peggy",  "colleen", "emily", "megan", "rachel", "wendy"]

target_words["afr_americans"]  = ["alonzo", "jamel", "lerone", "percell", "theo", "alphonse", "jerome", "leroy", "rasaan", "torrance", "darnell", "lamar", "lionel", "rashaun", "tyree", "deion", "lamont", "malik","terrence", "tyrone", "lavon", "marcellus", "terryl", "wardell", "aiesha", "lashelle", "nichelle", "shereen", "temeka", "ebony", "latisha", "shaniqua", "tameisha",  "jasmine", "latonya", "shanise", "tanisha", "tia", "lakisha", "latoya", "sharise", "tashika", "yolanda",  "malika", "tawanda", "yvette"]


target_words["male_names"]  = ["john","paul","mike","kevin","steve","greg","jeff", "bill"]
target_words["female_names"]  =    ["amy","joan","lisa","sarah","diana","kate","ann", "donna"]

attribute_words["male_terms"]  = ["male", "man", "boy", "brother", "he", "him","his", "son"]
attribute_words["female_terms"] =    ["female", "woman", "girl", "sister", "she","her", "hers", "daughter"]


attribute_words["unpleasant_3"]  = ["abuse", "crash", "filth", "murder", "sickness", "accident", "death", "grief", "poison", "stink", "assault", "disaster", "hatred",
                                  "pollute", "tragedy", "bomb", "divorce",
                                  "jail", "poverty", "ugly", "cancer", "kill",
                                  "rotten", "vomit"]


attribute_words["career"]  = ["executive","management","professional","corporation","salary","office","business", "career" ]
attribute_words["family"]  = ["home","parents","children","family","cousins","marriage","wedding", "relatives" ]




def statistic_test(X,Y,A,B):
    result = 0.0
    sum_X = 0.0
    sum_Y = 0.0

    for word_X in X:
        sum_X += sub_statistic_test(word_X, A,B)
    for word_Y in Y:
        sum_Y += sub_statistic_test(word_Y, A,B)

    return (sum_X - sum_Y)

def sub_statistic_test(w,A,B):
    result = 0.0
    sum_cos_A = 0.0
    sum_cos_B = 0.0

    for word_A in A:
        sum_cos_A += numpy.dot(model[w],model[word_A])/(numpy.linalg.norm(model[w])*numpy.linalg.norm(model[word_A]))
    for word_B in B:
        sum_cos_B += numpy.dot(model[w],model[word_B])/(numpy.linalg.norm(model[w])*numpy.linalg.norm(model[word_B]))

    return (sum_cos_A/len(A) - sum_cos_B/len(B))

def effect_size(x_words,y_words,a_attributes,b_attributes):
    # Effect size
    test_x = 0.0
    test_y = 0.0
    samples = []

    for word_x in target_words[x_words]:
        test_x += sub_statistic_test(word_x,attribute_words[a_attributes],attribute_words[b_attributes])
        samples.append(sub_statistic_test(word_x,attribute_words[a_attributes],attribute_words[b_attributes]))

    for word_y in target_words[y_words]:
        test_y += sub_statistic_test(word_y,attribute_words[a_attributes],attribute_words[b_attributes])
        samples.append(sub_statistic_test(word_y,attribute_words[a_attributes],attribute_words[b_attributes]))

    mean_x =  test_x/len(target_words[x_words])
    mean_y =  test_y/len(target_words[y_words])

    print("mean_x = " + str(mean_x))
    print("mean_y = " + str(mean_y))
    std_dev = numpy.std(samples)
    print("std-dev = " + str(std_dev))
    effect_size =  (mean_x - mean_y)/std_dev
    return effect_size




# Load model
model = gensim.models.Word2Vec.load("wiki.en.word2vec.model")


#Effect size:
X = "flowers_1"
Y = "insects_1"
A = "pleasant_1"
B = "unpleasant_1"

print("Effect-Size:" + str(effect_size(X,Y,A,B)))

#P-value
null_hipotese_evidance = 0
number_permitations = 0
test_statistic_value = statistic_test(target_words[X],target_words[Y],attribute_words[A],attribute_words[B])

# Encontra o maior set possivel de memso tamanho das duas classes
X_size =  len(target_words[X])
Y_size =  len(target_words[Y])
size = max(X_size, Y_size)
union = set(target_words[X] + target_words[Y])

permutations = itertools.combinations(union,size)

for i,permutation in enumerate(permutations):
    x_i = permutation
    y_i = union - set(permutation)
    test_value = statistic_test(x_i,y_i,attribute_words[A],attribute_words[B])
    if( test_value > test_statistic_value):
        null_hipotese_evidance += 1
    number_permitations += 1

    #if i == 1:
    #    for n in range(len(x_i)):
    #        print(x_i[n])

    if (i+1) % 1000 == 0:
        print("Acabou "+ str(i+1))
    if (i >= 10000):
        break

    #print(null_hipotese_evidance)
    #print(number_permitations)
    #print(null_hipotese_evidance/number_permitations)

print("P-Value:")
print(null_hipotese_evidance/number_permitations)






#cosine_similarity_prostitute = numpy.dot(model['woman'],model['prostitute'])/(numpy.linalg.norm(model['woman'])*numpy.linalg.norm(model['prostitute']))
#cosine_similarity_seductress =  numpy.dot(model['woman'],model['seductress'])/(numpy.linalg.norm(model['woman'])*numpy.linalg.norm(model['seductress']))
#print(cosine_similarity_prostitute,cosine_similarity_seductress)
#print(model.most_similar("woman"))
#antes = copy.deepcopy(model.wv["woman"])




