#!/bin/bash

BASE_DIR="../.."

#cat "$BASE_DIR/data/videos.jsonl" | jq -r .channel_id | uniq -c | awk '{printf "%s\t%s\n", $2, $1}' > "$BASE_DIR/data/n_videos.txt"
#cat "$BASE_DIR/data/comments.jsonl" | jq -r .channel_id | uniq -c | awk '{printf "%s\t%s\n", $2, $1}' > "$BASE_DIR/data/n_comments.txt"

cat "$BASE_DIR/data/videos-filtered.jsonl" | jq -r .channel_id | uniq -c | awk '{printf "%s\t%s\n", $2, $1}' > "$BASE_DIR/data/n_videos-filtered.txt"
cat "$BASE_DIR/data/comments-filtered.jsonl" | jq -r .channel_id | uniq -c | awk '{printf "%s\t%s\n", $2, $1}' > "$BASE_DIR/data/n_comments-filtered.txt"

paste -d $'\t' "$BASE_DIR/data/channels/list.txt" "$BASE_DIR/data/channels/n_subscribers.txt" "$BASE_DIR/data/n_videos.txt" "$BASE_DIR/data/n_comments.txt" "$BASE_DIR/data/n_videos-filtered.txt" "$BASE_DIR/data/n_comments-filtered.txt" > "$BASE_DIR/data/stats-full.txt"

echo -e "channel_id\tchannel_name\tn_subscribers\tn_videos\tn_comments\tn_videos-f\tn_comments-f" > "$BASE_DIR/data/stats.txt"
awk -F $'\t' '{printf "%s\t%s\t%s\t%s\t%s\n", $1, $2, $3, $5, $7, $9, $11}' "$BASE_DIR/data/stats-full.txt" >> "$BASE_DIR/data/stats.txt"

