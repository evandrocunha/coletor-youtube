#!/usr/bin/env Rscript

library(dplyr)
library(tidyr)
library(tibble)
library(stringr)
library(forcats)
library(ggplot2)
library(corrplot)
library(gridExtra)
library(viridis)

library(lsa)

channels_names <- read.table("../../data/channels_names.tsv", header=TRUE, sep="\t")
levels(channels_names$channel_type) <- c("wikipedia", "conservative", "general", "ignored")

video_stats <- read.table("../../data/video_stats.tsv", header=TRUE, sep="\t") %>%
    select(-favorite_count) %>%
    mutate(like_prop  = like_count/(like_count + dislike_count),
           like_prop2 = like_count/dislike_count)

df <- read.table("../../info/lexcat/lexcat-by_video.tsv", header=TRUE, sep="\t")
df$source <- factor(df$source, levels=c("transcript", "comments"))
levels(df$channel_type) <- c("conservative", "general")

df_stats <- df %>%
    group_by(channel_type, channel_id, source, lexcat) %>%
    summarise(total = sum(n_words)) %>%
    group_by(channel_type, channel_id, source) %>%
    mutate(perc=100*total/sum(total)) %>%
    left_join(channels_names) %>%
    ungroup() %>%
    select(channel_type, channel_name, source, lexcat, total, perc)


df_stats2 <- df_stats %>%
    group_by(channel_type, channel_name, source, lexcat) %>%
    summarise(n = n(),
              median = median(perc, na.rm=TRUE),
              avg = mean(perc, na.rm=TRUE),
              se = sqrt(var(perc)/length(perc))) %>%
    left_join(channels_names)
#df_stats$source <- factor(df_stats$source, levels=c("transcript", "comments"))
#levels(df_stats$channel_type) <- c("conservative", "general")

#ggplot(df_stats, aes(x=channel_name, y=lexcat, fill=perc)) +
#    facet_wrap(~source, ncol=2) +
#    geom_tile(size=0.5, color="black") +
#    geom_text(aes(label = round(perc, 1))) + 
#    scale_fill_gradient("Words (%)", low = "white", high = "steelblue") +
#    scale_x_discrete("Channel", position = "top") +
#    scale_y_discrete("Lexical Category") +
#    theme(axis.text.x = element_text(angle = 45, hjust = 0))
#ggsave("lexcat.pdf", width=14, height=50, limitsize=FALSE)

ggplot(df_stats %>% filter(lexcat %in% c("positive_emotion", "negative_emotion", 
                                         "violence", "dispute", "dominant_personality", 
                                         "hate", "aggression", "optimism", "pain")), 
       aes(x=lexcat, y=source, fill=perc)) +
    facet_grid(channel_type + channel_name ~ ., switch="y") +
    geom_tile() +
    geom_text(aes(label = round(perc, 1)), color="gray") + 
    scale_x_discrete("Lexical Category", position = "top") +
    scale_y_discrete("Source") +
    scale_fill_viridis("Words (%)", option="plasma") +
    theme(strip.text.y = element_text(angle = 180),
          axis.text.x = element_text(angle = 45, hjust = 0),
          legend.position="bottom")
ggsave("lexcat-selected.pdf", width=7, height=13)

ggplot(df_stats %>% filter(lexcat %in% c("positive_emotion", "negative_emotion", 
                                         "violence", "dispute", "dominant_personality", 
                                         "hate", "aggression", "optimism", "pain")) %>%
                    mutate(channel_type = fct_recode(channel_type, "conserv." = "conservative", 
                                                                   "general" = "general")), 
       aes(x=channel_type, y=perc, fill=source)) +
    facet_wrap(~ lexcat, ncol=5, scale="free_y") +
    geom_boxplot() +
    scale_x_discrete("Channel Type") +
    scale_y_continuous("Words (%)") +
    scale_fill_brewer(palette="Set1") +
    theme(legend.position="top")
ggsave("lexcat-selected-boxplot.pdf", width=12, height=5)

#df_diff <- df_stats %>%
#    select(-total) %>%
#    spread(source, perc) %>%
#    mutate(diff = comments - transcript)
#    #mutate(diff = (comments - transcript)/transcript)
#    #mutate(diff = if(comments > transcript) (comments - transcript)/transcript else -(transcript - comments)/comments)
#
#ggplot(df_diff, aes(x=channel_name, y=lexcat, fill=diff)) +
#    geom_tile(size=0.5, color="black") +
#    geom_text(aes(label = round(diff, 1))) + 
#    scale_fill_gradient("Words (%)", low = "red", high = "green") +
#    scale_x_discrete("Channel", position = "top") +
#    scale_y_discrete("Lexical Category") +
#    theme(axis.text.x = element_text(angle = 45, hjust = 0))
#
#ggsave("lexcat-diff.pdf", width=8, height=50, limitsize=FALSE)

# Similarity by video

df_stats <- df %>%
    group_by(channel_type, video_id, source) %>%
    mutate(perc=100*n_words/sum(n_words)) %>%
    select(-n_words) %>%
    spread(source, perc) %>%
    group_by(channel_type, channel_id, video_id) %>%
    summarise(correlation = cor(comments, transcript),
              kendall = cor(comments, transcript, method="kendall"),
              cosine = cosine(comments, transcript)[1]) %>%
    gather(metric, similarity, -channel_type, -channel_id, -video_id) %>%
    left_join(channels_names)

temp_order <- df_stats %>%
    filter(metric == "cosine") %>%
    group_by(channel_type, channel_id) %>%
    summarise(med=median(similarity, na.rm=TRUE)) %>%
    arrange(med) %>%
    left_join(channels_names)

df_stats$channel_name <- factor(df_stats$channel_name, levels=temp_order$channel_name)

ggplot(df_stats %>% filter(metric =="cosine"), aes(x=channel_name, y=similarity)) +
    facet_wrap(~ channel_type, ncol=1, scales="free_y") +
    geom_boxplot() +
    coord_flip() +
    scale_x_discrete("Channel") +
    scale_y_continuous("Cosine Similarity")
ggsave("lexcat-similarity.pdf", width=5, height=10)

#ggplot(df_stats %>% filter(metric =="cosine"), aes(x=channel_name, y=similarity)) +
#    geom_boxplot() +
#    scale_x_discrete("Channel", position = "top") +
#    scale_y_continuous("Cosine Similarity") +
#    theme(axis.text.x = element_text(angle = 45, hjust = 0))
#ggsave("lexcat-similarity-WIDE.pdf", width=7, height=5)


## Similarity vs categories

df_avg <- df_stats %>% 
    group_by(channel_type, channel_id, metric) %>% 
    summarise(avg = mean(similarity, na.rm=TRUE)) %>%
    ungroup() %>%
    mutate(channel_id = factor(channel_id),
           lexcat = factor(metric)) %>%
    select(channel_type, channel_id, lexcat, avg)

df_avg2 <- df %>%
    group_by(channel_type, video_id, source) %>%
    mutate(perc=100*n_words/sum(n_words)) %>%
    select(-n_words) %>%
    group_by(channel_type, channel_id, source, lexcat) %>%
    summarise(avg = mean(perc, na.rm=TRUE)) %>%
    #filter(source == "transcript") %>%
    filter(source == "comments") %>%
    ungroup() %>%
    select(-source)

df_avg3 <- video_stats %>% 
    gather(metric, value, -channel_type, -channel_id, -video_id) %>% 
    mutate(lexcat = sprintf("stats-%s", metric)) %>%
    group_by(channel_type, channel_id, lexcat) %>%
    summarise(avg = mean(value, na.rm=TRUE))

df_all <- df_avg %>% 
    bind_rows(df_avg2) %>%
    bind_rows(df_avg3) %>% 
    arrange(channel_id) %>%
    select(channel_type, channel_id, lexcat, avg)

df_cor_conservative <- df_all %>% 
    spread(lexcat, avg) %>%
    filter(channel_type == "conservative") %>%
    select(-channel_type, -channel_id) %>%
    cor(use="pairwise.complete.obs") %>%
    as.data.frame() %>%
    rownames_to_column("metric") %>%
    arrange(-cosine) %>%
    mutate(channel_type="conservative") %>%
    select(metric, channel_type, cosine, kendall, correlation) 

df_cor_general <- df_all %>% 
    spread(lexcat, avg) %>%
    filter(channel_type == "general") %>%
    select(-channel_type, -channel_id) %>%
    cor(use="pairwise.complete.obs") %>%
    as.data.frame() %>%
    rownames_to_column("metric") %>%
    arrange(-cosine) %>%
    mutate(channel_type="general") %>%
    select(metric, channel_type, cosine, kendall, correlation) 

df_cor <- rbind(df_cor_conservative, df_cor_general) %>% arrange(metric)
df_cor <- df_cor %>% 
    filter(!(metric %in% c("correlation", "kendall", "cosine"))) %>%
    mutate(channel_type = fct_recode(channel_type, "cons." = "conservative", "gen." = "general"))

top_conservative <- (df_cor %>% filter(channel_type == "cons.") %>% filter(!str_detect(metric, "stats-.*")) %>% arrange(-abs(correlation)))$metric
top_general <- (df_cor %>% filter(channel_type == "gen.") %>% filter(!str_detect(metric, "stats-.*")) %>% arrange(-abs(correlation)))$metric

df_cor_top_conservative <- df_cor %>% filter(metric %in% top_conservative[1:30])
df_cor_top_conservative$metric <- factor(df_cor_top_conservative$metric, levels=top_conservative)

df_cor_top_general <- df_cor %>% filter(metric %in% top_general[1:30])
df_cor_top_general$metric <- factor(df_cor_top_general$metric, levels=top_general)

plot_conservative <- ggplot(df_cor_top_conservative, aes(x=channel_type, y=factor(0), fill=correlation)) +
                     facet_wrap(~ metric, nrow=3) +
                     #geom_col() +
                     geom_tile() +
                     scale_fill_gradient2(limits=c(-1, 1)) +
                     geom_text(aes(label=sprintf("%.2f", correlation))) +
                     ggtitle("Conservative") +
                     theme(axis.title.y=element_blank(), axis.text.y=element_blank(), axis.ticks.y=element_blank())

plot_general <- ggplot(df_cor_top_general, aes(x=channel_type, y=factor(0), fill=correlation)) +
                     facet_wrap(~ metric, nrow=3) +
                     #geom_col() +
                     geom_tile() +
                     scale_fill_gradient2(limits=c(-1, 1)) +
                     geom_text(aes(label=sprintf("%.2f", correlation))) +
                     ggtitle("General") +
                     theme(axis.title.y=element_blank(), axis.text.y=element_blank(), axis.ticks.y=element_blank())

plot <- arrangeGrob(plot_conservative, plot_general, ncol=1)
ggsave("lexcat-ranking-correlation.pdf", plot, width=12, height=6)


df_plot <- df_all %>%
    group_by(channel_type, channel_id) %>%
    left_join(df_all %>%
                  filter(lexcat == "cosine") %>%
                  select(channel_id, avg), 
              by="channel_id") %>%
    rename(lexcat_value=avg.x,
           cosine_similarity=avg.y) %>%
    group_by(channel_type, lexcat) %>%
    mutate(cor = cor(cosine_similarity, lexcat_value),
           pvalue = cor.test(cosine_similarity, lexcat_value)$p.value,
           cor_x = max(cosine_similarity)*0.90,
           cor_y = max(lexcat_value)*1.1) %>%
    arrange(lexcat, channel_type) %>%
    left_join(channels_names)

plot_conservative <- 
    ggplot(df_plot %>% 
               filter(lexcat %in% c("violence", 
                                    "dispute",
                                    "dominant_personality", 
                                    "hate", 
                                    "aggression", 
                                    "optimism", 
                                    "positive_emotion",
                                    "pain")) %>%
               filter(channel_type == "conservative"), 
       aes(x=cosine_similarity, y=lexcat_value)) +
    facet_wrap(~ lexcat, scales="free", ncol=2) +
    geom_point() +
    geom_smooth(method="lm", se=FALSE) +
    geom_text(aes(label=channel_name), check_overlap=TRUE, vjust = 0) +
    geom_text(aes(x=cor_x, y=cor_y, label=sprintf("cor = %.2f", cor)), color="blue") +
    ggtitle("Conservative")

plot_general <- 
    ggplot(df_plot %>% 
               filter(lexcat %in% c("violence", 
                                    "dispute",
                                    "dominant_personality", 
                                    "hate", 
                                    "aggression", 
                                    "optimism", 
                                    "positive_emotion",
                                    "pain")) %>%
               filter(channel_type == "general"), 
       aes(x=cosine_similarity, y=lexcat_value)) +
    facet_wrap(~ lexcat, scales="free", ncol=2) +
    geom_point() +
    geom_smooth(method="lm", se=FALSE) +
    geom_text(aes(label=channel_name), check_overlap=TRUE, vjust = 0) +
    geom_text(aes(x=cor_x, y=cor_y, label=sprintf("cor = %.2f", cor)), color="blue") +
    ggtitle("General")

plot <- arrangeGrob(plot_conservative, plot_general, ncol=2)
ggsave("lexcat-correlation.pdf", plot, width=14, height=10)

#ggplot(df_plot %>% filter(str_detect(lexcat, "stats-.*")), 
ggplot(df_plot %>% filter(lexcat %in% c("stats-view_count", "stats-comment_count",
                                        "stats-like_prop", "stats-video_duration")), 
       aes(x=cosine_similarity, y=lexcat_value)) +
    facet_wrap(channel_type ~ lexcat, scales="free", nrow=2) +
    geom_point() +
    geom_smooth(method="lm", se=FALSE) +
    geom_text(aes(label=channel_name), check_overlap=TRUE, vjust = 0) +
    geom_text(aes(x=cor_x, y=cor_y, label=sprintf("cor = %.2f", cor)), color="blue")
ggsave("videostats-correlation.pdf", width=12, height=5)

