#!/usr/bin/env python3

import re
import html
import json
import collections
import wordcloud

def clean_html(raw_text):
    text = html.unescape(raw_text)
    text = re.sub("<.*?>", "", text)
    return text

def get_words(text):
    stopwords = set([line.rstrip() for line in open("stopwords-english.txt", encoding="utf-8")])
    text = re.sub(r"https?://\S+", "", text)
    text = clean_html(text)
    words = [word.lower() for word in re.findall("\w+", text)]
    words = [word for word in words if word not in stopwords]
    words = [word for word in words if len(word) > 2]
    return words

def draw(freqs, outfile_name):

    wc = wordcloud.WordCloud(width=1024, height=1024, 
                             prefer_horizontal=1.0)

    wc.generate_from_frequencies(dict(freqs))

    wc.to_file(outfile_name)


DIR_BASE = "../.."

# WARNING: assumes videos are ordered by channel
with open("{}/data/videos.jsonl".format(DIR_BASE), "r") as infile:

    actual_channel = None

    actual_counter_videodesc = None
    actual_counter_transcript = None
    
    for line in infile:
        obj = json.loads(line)

        channel = obj["channel_id"]

        if channel != actual_channel:

            if actual_channel:

                freqs = list(actual_counter_videodesc.most_common(1500))
                draw(freqs, "{}/info/wordclouds/channel_{}-video_desc.png".format(DIR_BASE, actual_channel))
                with open("{}/info/wordclouds/channel_{}-video_desc.txt".format(DIR_BASE, actual_channel), "w", encoding="utf-8") as outfile:
                    for word, count in freqs:
                        outfile.write("{}\t{}\n".format(word, count))

                freqs = list(actual_counter_transcript.most_common(1500))
                draw(freqs, "{}/info/wordclouds/channel_{}-transcript.png".format(DIR_BASE, actual_channel))
                with open("{}/info/wordclouds/channel_{}-transcript.txt".format(DIR_BASE, actual_channel), "w", encoding="utf-8") as outfile:
                    for word, count in freqs:
                        outfile.write("{}\t{}\n".format(word, count))

            actual_channel = channel
            actual_counter_videodesc = collections.Counter()
            actual_counter_transcript = collections.Counter()

        text = obj["video_desc"]
        words = get_words(text)
        actual_counter_videodesc.update(words)

        text = obj["transcript"]
        words = get_words(text)
        actual_counter_transcript.update(words)


# WARNING: assumes comments are ordered by channel
with open("{}/data/comments.jsonl".format(DIR_BASE), "r") as infile:

    actual_channel = None

    actual_counter_comments = None
    
    for line in infile:
        obj = json.loads(line)

        channel = obj["channel_id"]

        if channel != actual_channel:

            if actual_channel:

                freqs = list(actual_counter_comments.most_common(1500))
                draw(freqs, "{}/info/wordclouds/channel_{}-comments.png".format(DIR_BASE, actual_channel))
                with open("{}/info/wordclouds/channel_{}-comments.txt".format(DIR_BASE, actual_channel), "w", encoding="utf-8") as outfile:
                    for word, count in freqs:
                        outfile.write("{}\t{}\n".format(word, count))

            actual_channel = channel
            actual_counter_comments = collections.Counter()

        text = obj["comment_text"]
        words = get_words(text)
        actual_counter_comments.update(words)

