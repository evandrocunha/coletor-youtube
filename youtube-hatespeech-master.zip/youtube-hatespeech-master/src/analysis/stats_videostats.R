#!/usr/bin/env Rscript

library(tidyverse)
library(forcats)

library(Cairo)

# Read data

channels_names <- read.table("../../data/channels_names.tsv", header=TRUE, sep="\t") %>%
    mutate(channel_type = fct_recode(channel_type,
        "right-wing" = "altright",
        "baseline"     = "general"
    ))

video_stats <- read.table("../../data/video_stats.tsv", header=TRUE, sep="\t") %>%
    mutate(channel_type = fct_recode(channel_type,
        "right-wing" = "altright",
        "baseline"     = "general"
    )) %>%
    select(-favorite_count) %>%
    mutate(like_prop  = like_count/(like_count + dislike_count),
           like_prop2 = like_count/dislike_count,
           like_view = like_count/view_count,
           dislike_view = dislike_count/view_count)

df_plot <- video_stats %>%
    gather(metric, value, -channel_type, -channel_id, -video_id) %>%
    filter(metric %in% c("like_prop", "like_view", "dislike_view")) %>%
    filter(is.finite(value)) %>%
    mutate(is_log = metric %in% c("like_view",
                                  "dislike_view")) %>%
    mutate(value_plot = if_else(is_log, log10(value), value)) %>%
    mutate(metric = fct_relevel(metric,
        "like_prop",
        "like_view",
        "dislike_view"
    )) %>% 
    mutate(metric_plot = fct_recode(metric,
        "# likes / # iteracs."       = "like_prop",
        "# likes / # views (10ˣ)"    = "like_view",
        "# disl. / # views (10ˣ)"    = "dislike_view"
    ))

df_table <- df_plot %>%
    group_by(channel_type, metric_plot) %>%
    summarise(n=n(),
              avg=mean(value, na.rm=TRUE),
              sd=sd(value, na.rm=TRUE)) %>%
    mutate(label = if_else(channel_type=="right-wing", 
               sprintf("Csv: avg=%.3f, sd=%.3f", avg, sd),  
               sprintf("Bsl: avg=%.3f, sd=%.3f", avg, sd)),
           y = if_else(channel_type=="right-wing", 1.0, 0.9))

df_plot %>%
    mutate(metric = fct_recode(metric,
        "# likes / # iteracs." = "like_prop",
        "# likes / # views"    = "like_view",
        "# disl. / # views"    = "dislike_view"
    )) %>% 
    ggplot(aes(x=channel_type, y=value)) +
        facet_wrap(~ metric, scales="free") +
        geom_boxplot()
ggsave("videostats-boxplot.pdf", device=cairo_pdf, width=6, height=2.5)

ggplot(df_plot, aes(x=value_plot, color=channel_type)) +
    facet_wrap(~ metric_plot, scales="free") +
    stat_ecdf() +
    geom_text(data=df_table, 
              aes(y=y, label=label, color=channel_type), 
              x=-Inf, hjust=0, vjust=1) +
    theme(legend.position="top") 
ggsave("videostats-cdf.pdf", device=cairo_pdf, width=10, height=4)

