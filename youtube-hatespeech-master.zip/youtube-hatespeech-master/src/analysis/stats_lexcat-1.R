#!/usr/bin/env Rscript

library(dplyr)
library(tidyr)
library(stringr)

options(error=traceback)

# Videos

df_videos <- read.table("../../info/lexcat/videos.tsv", header=TRUE, sep="\t")

df_videos_byvideo <- df_videos %>% 
    gather(lexcat, n_words, -channel_type, -channel_id, -video_id, factor_key=TRUE) %>%
    group_by(channel_type, channel_id, video_id, lexcat) %>%
    summarise(n_words = sum(n_words))

levels(df_videos_byvideo$lexcat) <- str_replace(levels(df_videos_byvideo$lexcat), "lexcat_", "") 
df_videos_byvideo$source <- "transcript"


# Comments

df_comments <- read.table("../../info/lexcat/comments-by_video.tsv", header=TRUE, sep="\t")

df_comments_byvideo <- df_comments %>% 
    gather(lexcat, n_words, -channel_type, -channel_id, -video_id, factor_key=TRUE) %>%
    group_by(channel_type, channel_id, video_id, lexcat) %>%
    summarise(n_words = sum(n_words))

levels(df_comments_byvideo$lexcat) <- str_replace(levels(df_comments_byvideo$lexcat), "lexcat_", "") 
df_comments_byvideo$source <- "comments"


# All

df_all <- rbind(df_videos_byvideo, df_comments_byvideo)
df_all$source <- factor(df_all$source)
df_all <- df_all %>% select(channel_type, channel_id, video_id, source, lexcat, n_words)

write.table(df_all, "../../info/lexcat/lexcat-by_video.tsv", sep="\t", row.names=FALSE, quote=FALSE)

