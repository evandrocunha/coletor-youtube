#!/usr/bin/env Rscript

library(dplyr)
library(tidyr)
library(ggplot2)
library(tibble)

library(lsa)

channels_names <- read.table("../../data/channels_names.tsv", header=TRUE, sep="\t")

df_altright <- read.table("../../data/lda/videos-comments-altright.tsv", header=TRUE, sep="\t") %>% 
    mutate(source = type) %>% select(-type)
df_altright$channel_type <- "altright"
levels(df_altright$source) <- c("comments", "transcript")

df_general <- read.table("../../data/lda/videos-comments-baseline.tsv", header=TRUE, sep="\t") %>%
    mutate(source = type) %>% select(-type)
df_general$channel_type <- "general"
levels(df_general$source) <- c("comments", "transcript")

df <- df_altright %>% 
    rbind(df_general) %>%
    gather(topic, score, -source, -channel_id, -video_id, -channel_type) %>%
    select(channel_type, channel_id, video_id, source, topic, score) %>%
    arrange(channel_type, channel_id, video_id, topic)


# Similarity by video

df_stats <- df %>%
    group_by(channel_type, video_id, source) %>%
    spread(source, score) %>%
    group_by(channel_type, channel_id, video_id) %>%
    summarise(correlation = cor(comments, transcript),
              kendall = cor(comments, transcript, method="kendall"),
              cosine = cosine(comments, transcript)[1]) %>%
    gather(metric, similarity, -channel_type, -channel_id, -video_id) %>%
    left_join(channels_names)

temp_order <- df_stats %>%
    filter(metric == "cosine") %>%
    group_by(channel_type, channel_id) %>%
    summarise(med=median(similarity, na.rm=TRUE)) %>%
    arrange(med) %>%
    left_join(channels_names)

df_stats$channel_name <- factor(df_stats$channel_name, levels=temp_order$channel_name)

ggplot(df_stats %>% filter(metric =="cosine"), aes(x=channel_name, y=similarity)) +
    facet_wrap(~ channel_type, ncol=1, scales="free_y") +
    geom_boxplot() +
    coord_flip() +
    scale_x_discrete("Channel") +
    scale_y_continuous("Cosine Similarity")
ggsave("topic-similarity.pdf", width=5, height=10)

## Similarity vs categories

df_avg <- df_stats %>% 
    group_by(channel_type, channel_id, metric) %>% 
    summarise(avg = mean(similarity, na.rm=TRUE)) %>%
    ungroup() %>%
    mutate(channel_id = factor(channel_id),
           topic = factor(metric)) %>%
    select(channel_type, channel_id, topic, avg)

df_avg2 <- df %>%
    group_by(channel_type, video_id, source) %>%
    group_by(channel_type, channel_id, source, topic) %>%
    summarise(avg = mean(score, na.rm=TRUE)) %>%
    #filter(source == "transcript") %>%
    filter(source == "comments") %>%
    ungroup() %>%
    select(-source)

df_all <- rbind(df_avg, df_avg2) %>% 
    arrange(channel_id) %>%
    select(channel_type, channel_id, topic, avg)

df_cor_altright <- df_all %>% 
    spread(topic, avg) %>%
    filter(channel_type == "altright") %>%
    select(-channel_type, -channel_id) %>%
    cor(use="pairwise.complete.obs") %>%
    as.data.frame() %>%
    rownames_to_column("metric") %>%
    arrange(-cosine) %>%
    mutate(channel_type="altright") %>%
    select(metric, channel_type, cosine, kendall, correlation) 

df_cor_general <- df_all %>% 
    spread(topic, avg) %>%
    filter(channel_type == "general") %>%
    select(-channel_type, -channel_id) %>%
    cor(use="pairwise.complete.obs") %>%
    as.data.frame() %>%
    rownames_to_column("metric") %>%
    arrange(-cosine) %>%
    mutate(channel_type="general") %>%
    select(metric, channel_type, cosine, kendall, correlation) 

df_cor <- rbind(df_cor_altright, df_cor_general) %>% arrange(metric)
df_cor <- df_cor %>% filter(!(metric %in% c("correlation", "kendall", "cosine")))
#df_cor$metric <- factor(df_cor$metric, levels=(df_cor %>% filter(channel_type == "altright") %>% arrange(-correlation))$metric)
df_cor$metric <- factor(df_cor$metric, levels=(df_cor %>% filter(channel_type == "general") %>% arrange(-correlation))$metric)

(df_cor %>% filter(channel_type == "altright") %>% arrange(-correlation))$metric[1:10]
(df_cor %>% filter(channel_type == "general") %>% arrange(-correlation))$metric[1:10]

ggplot(df_cor, aes(x=channel_type, y=correlation)) +
    facet_wrap(~ metric) +
    geom_col() +
    geom_text(aes(label=sprintf("%.2f", correlation)), color="blue")
ggsave("topic-ranking-correlation-matrix.pdf", width=20, height=20)

