library(dplyr)
library(tidyr)
library(tibble)
library(stringr)
library(forcats)
library(ggplot2)
library(corrplot)
library(gridExtra)
library(viridis)

library(lsa)

channels_names <- read.table("../../data/channels_names.tsv", header=TRUE, sep="\t")
levels(channels_names$channel_type) <- c("wikipedia", "conservative", "general", "ignored")

video_stats <- read.table("../../data/video_stats.tsv", header=TRUE, sep="\t") %>%
    select(-channel_type, -favorite_count) %>%
    mutate(like_prop  = like_count/(like_count + dislike_count))

df <- read.table("../../info/lexcat/lexcat-by_video.tsv", header=TRUE, sep="\t")
df$source <- factor(df$source, levels=c("transcript", "comments"))
levels(df$channel_type) <- c("conservative", "general")

df_stats <- video_stats %>%
    gather(stat, value, -channel_id, -video_id) %>%
    group_by(channel_id, stat) %>%
    summarise(n = n(),
              median = median(value, na.rm=TRUE),
              avg = mean(value, na.rm=TRUE),
              se = sqrt(var(value)/length(value)),
              low = wilcox.test(value, alternative="two.sided", correct=TRUE, conf.int=TRUE, conf.level=0.95)$conf.int[1],
              high = wilcox.test(value, alternative="two.sided", correct=TRUE, conf.int=TRUE, conf.level=0.95)$conf.int[2]) %>%
    left_join(channels_names)

ggplot(df_stats, aes(x=channel_name, y=avg, color=channel_type)) +
    facet_wrap(~ stat, scale="free") +
    geom_point() +
    geom_errorbar(aes(ymin=avg-se, ymax=avg+se)) +
    theme(legend.position="top")

#df_stats <- df %>%
#    group_by(channel_type, channel_id, video_id, source, lexcat) %>%
#    summarise(total = sum(n_words)) %>%
#    group_by(channel_type, channel_id, video_id, source) %>%
#    mutate(perc=100*total/sum(total)) %>%
#    ungroup()
#
#ggplot(df_stats %>% filter(lexcat %in% c("positive_emotion", "negative_emotion", 
#                                         "violence", "dispute", "dominant_personality", 
#                                         "hate", "aggression", "optimism", "pain")), 
#       aes(x=channel_type, y=perc, fill=source)) +
#    facet_wrap(~ lexcat, ncol=5, scale="free_y") +
#    geom_boxplot(notch=TRUE) +
#    scale_x_discrete("Channel Type") +
#    scale_y_continuous("Words (%)") +
#    scale_fill_brewer(palette="Set1") +
#    theme(legend.position="top")
#ggsave("charact-lexcat-boxplot.pdf", width=12, height=5)

