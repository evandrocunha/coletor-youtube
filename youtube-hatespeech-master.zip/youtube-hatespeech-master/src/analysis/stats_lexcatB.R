#!/usr/bin/env Rscript

library(tidyverse)
library(stringr)
library(forcats)
library(broom)
library(magrittr)

library(corrplot)
library(gridExtra)
library(viridis)

library(lsa)


# Read data

channels_names <- read.table("../../data/channels_names.tsv", header=TRUE, sep="\t") %>%
    mutate(channel_type = fct_recode(channel_type,
        "right-wing" = "altright",
        "baseline"     = "general"
    ))

video_stats <- read.table("../../data/video_stats.tsv", header=TRUE, sep="\t") %>%
    mutate(channel_type = fct_recode(channel_type,
        "right-wing" = "altright",
        "baseline"     = "general"
    )) %>%
    select(-favorite_count) %>%
    mutate(like_prop  = like_count/(like_count + dislike_count),
           like_prop2 = like_count/dislike_count)

target_categories <- read.table("../../data/lexcat-categories.tsv", header=TRUE, sep="\t")

df <- read.table("../../info/lexcat/lexcat-by_video.tsv", header=TRUE, sep="\t") %>%
    mutate(
        channel_type = fct_recode(channel_type,
            "right-wing" = "altright",
            "baseline"     = "general"),
        source = fct_recode(source,
            "caption" = "transcript")
    ) %>%
    mutate(source = fct_relevel(source,
        "caption",
        "comments"
    )) %>%
    filter(lexcat %in% target_categories$metric)
    #%>% select(-channel_type)


# Measure

df_video <- df %>%
    group_by(channel_id, video_id, source, lexcat) %>%
    summarise(total = sum(n_words)) %>%
    group_by(channel_id, video_id, source) %>%
    mutate(perc=if_else(total > 0, 100*total/sum(total), 0)) %>%
    left_join(channels_names, by="channel_id") %>%
    mutate(channel_name = factor(channel_name)) %>%
    ungroup() %>%
    select(channel_type, channel_id, video_id, source, lexcat, total, perc)

df_channel <- df %>%
    group_by(channel_id, source, lexcat) %>%
    summarise(total = sum(n_words)) %>%
    group_by(channel_id, source) %>%
    mutate(perc=100*total/sum(total)) %>%
    left_join(df_video %>%
        group_by(channel_id, source, lexcat) %>%
        summarise(perc_avg = mean(perc, na.rm=TRUE)),
    by=c("channel_id", "source", "lexcat")) %>%
    left_join(channels_names, by="channel_id") %>%
    mutate(channel_name = factor(channel_name)) %>%
    ungroup() %>%
    select(channel_type, channel_id, channel_name, source, lexcat, total, perc, perc_avg)

df_video_stats <- df_video %>%
    group_by(channel_type, source, lexcat) %>%
    summarise(avg = mean(perc, na.rm=TRUE)) %>%
    ungroup()
    

# Frequency

ggplot(df_channel, aes(x=lexcat, y=source, fill=perc)) +
    facet_grid(channel_type + channel_name ~ ., switch="y") +
    geom_tile() +
    geom_text(aes(label = round(perc, 0)), color="gray") + 
    scale_x_discrete("Lexical Category", position = "top") +
    scale_y_discrete("Source") +
    scale_fill_viridis("Words (%)", option="plasma") +
    theme(strip.text.y = element_text(angle = 180),
          axis.text.x = element_text(angle = 45, hjust = 0),
          legend.position="bottom")
ggsave("lexcatB-matrix.pdf", width=15, height=12)

df_channel %>%
    mutate(channel_type = fct_recode(channel_type, "right-w." = "right-wing", "basel." = "baseline")) %>%
    left_join(target_categories, by=c("lexcat" = "metric")) %>%
    ggplot(aes(x=channel_type, y=perc_avg, fill=source)) +
        facet_wrap(~ lexcat_cat + lexcat, ncol=7, scale="free_y") +
        geom_boxplot() +
        scale_x_discrete("Channel Type") +
        scale_y_continuous("Words % (avg. channel)") +
        scale_fill_brewer(palette="Set1") +
        theme(legend.position="top")
ggsave("lexcatB-bychannel-boxplot.pdf", width=12, height=6)

df_video_stats %>%
    mutate(channel_type = fct_recode(channel_type, "right-w." = "right-wing", "basel." = "baseline")) %>%
    ggplot(aes(x=channel_type, y=avg, fill=source)) +
        facet_wrap(~ lexcat, ncol=7, scale="free_y") +
        geom_col(position="dodge") +
        scale_x_discrete("Channel Type") +
        scale_y_continuous("Words (%)") +
        scale_fill_brewer(palette="Set1") +
        theme(legend.position="bottom")
ggsave("lexcatB-byvideo-boxplot.pdf", width=12, height=6)


# Similarity by video

df_similarity <- df_video %>%
    select(-total) %>%
    spread(source, perc) %>%
    filter(!is.na(caption) & !is.na(comments)) %>%
    group_by(channel_type, channel_id, video_id) %>%
    summarise(similarity = cosine(comments, caption)[1]) %>%
    left_join(channels_names %>% select(-channel_type), by="channel_id")

channel_order <- df_similarity %>%
    group_by(channel_type, channel_id, channel_name) %>%
    summarise(med=median(similarity, na.rm=TRUE)) %>%
    arrange(med)

df_similarity %<>% mutate(channel_name = factor(channel_name, levels=channel_order$channel_name))
                          
ggplot(df_similarity, aes(x=channel_name, y=similarity)) +
    facet_grid(channel_type ~ ., scales="free_y", space="free", switch="y") +
    geom_boxplot() +
    coord_flip() +
    scale_x_discrete("Channel") +
    scale_y_continuous("Cosine Similarity")
ggsave("lexcatB-similarity.pdf", width=5, height=6)


# Avg Similarity vs Avg Fraction Empath

df_similarity_avg <- df_similarity %>% 
    group_by(channel_id) %>% 
    summarise(avg_similarity = mean(similarity, na.rm=TRUE))

df_lexcat_avg <- df_channel %>%
    mutate(metric = lexcat,
           avg_value = perc_avg) %>%
    select(channel_type, channel_id, source, metric, avg_value)

df_videostats_avg <- video_stats %>% 
    gather(metric, value, -channel_type, -channel_id, -video_id) %>% 
    group_by(channel_type, channel_id, metric) %>%
    summarise(avg_value = mean(value, na.rm=TRUE)) %>%
    mutate(source = "stats") %>%
    select(channel_type, channel_id, source, metric, avg_value)

df_avg <- df_lexcat_avg %>% 
    bind_rows(df_videostats_avg) %>%
    left_join(df_similarity_avg, by="channel_id") %>%
    ungroup() %>%
    left_join(channels_names %>% select(-channel_type), by="channel_id") %>%
    left_join(target_categories, by="metric") %>%
    mutate(channel_type = factor(channel_type),
           channel_id = factor(channel_id),
           source = factor(source),
           metric = factor(metric),
           lexcat_cat = factor(lexcat_cat)) %>%
    select(source, lexcat_cat, metric, channel_type, channel_id, channel_name, avg_value, avg_similarity) %>%
    arrange(source, lexcat_cat, metric, channel_type, channel_name)

df_cor <- df_avg %>%
    group_by(source, lexcat_cat, metric, channel_type) %>%
    do(tidy(cor.test(.$avg_value, .$avg_similarity, method="pearson"))) %>%
    ungroup() %>%
    mutate(correlation = estimate) %>%
    select(source, lexcat_cat, metric, channel_type, correlation, p.value) 

df_cor %>% filter(source != "stats") %>%
    mutate(channel_type = fct_recode(channel_type, "right-w." = "right-wing", "basel." = "baseline")) %>%
    ggplot(aes(x=metric, y=channel_type, fill=correlation)) +
        facet_grid(source ~ lexcat_cat, scales="free", space="free", switch="y") +
        geom_tile() +
        geom_text(aes(label=sprintf("%.2f", correlation), color = p.value < 0.05)) +
        scale_x_discrete("Lexical Category", position="top") +
        scale_y_discrete("Channel Type") +
        scale_fill_gradient2(limits=c(-1, 1)) +
        scale_color_manual(values=c("black", "green"), guide=FALSE) +
        theme(axis.text.x = element_text(angle = 45, hjust = 0))
ggsave("lexcatB-bychannel-cortable.pdf", width=12, height=3)

df_avg %>%
    filter(source == "stats") %>%
    filter(metric %in% c("view_count", "comment_count",
                         "like_prop", "video_duration")) %>%
ggplot(aes(x=avg_similarity, y=avg_value)) +
    facet_wrap(channel_type ~ metric, scales="free", nrow=2) +
    geom_point() +
    geom_smooth(method="lm", se=FALSE) +
    geom_text(aes(label=channel_name), check_overlap=TRUE, vjust = 0) +
    geom_text(data=df_cor %>% filter(metric %in% c("view_count", "comment_count", 
                                                   "like_prop", "video_duration")) %>%
                              filter(p.value < 0.05),
              aes(label=sprintf("cor = %.2f", correlation)), 
              x=Inf, y=Inf, hjust=1, vjust=1, color="blue")
ggsave("lexcatB-bychannel-videostats-correlation.pdf", width=12, height=5)

df_avg %>%
    left_join(df_cor, by=c("source", "lexcat_cat", "metric", "channel_type")) %>%
    filter(source %in% c("caption", "comments")) %>%
    filter(p.value < 0.05) %>%
    ggplot(aes(x=avg_similarity, y=avg_value)) +
        facet_wrap(~ channel_type + source + metric, scales="free", ncol=7) +
        geom_point() +
        geom_smooth(method="lm", se=FALSE) +
        geom_text(aes(label=channel_name), check_overlap=TRUE, vjust = 0) +
        geom_text(aes(label=sprintf("cor = %.2f", correlation)), 
                  x=-Inf, y=Inf, hjust=0, vjust=1, color="blue") +
        scale_x_continuous("Similarity (channel avg.)") +
        scale_y_continuous("Words % (channel avg.)") 
ggsave("lexcatB-bychannel-correlation.pdf", width=16, height=5)


# Similarity vs Fraction Empath

df_similarity_all <- df_similarity %>% 
    ungroup() %>%
    select(video_id, similarity)

df_lexcat_all <- df_video %>% 
    mutate(metric = lexcat, value=perc) %>%
    select(channel_type, channel_id, video_id, source, metric, value)

df_videostats_all <- video_stats %>% 
    gather(metric, value, -channel_type, -channel_id, -video_id) %>% 
    mutate(source = "stats") %>%
    select(channel_type, channel_id, video_id, source, metric, value)

df_all <- df_lexcat_all %>% 
    bind_rows(df_videostats_all) %>%
    left_join(df_similarity_all, by="video_id") %>%
    ungroup() %>%
    left_join(channels_names %>% select(-channel_type), by="channel_id") %>%
    mutate(channel_type = factor(channel_type),
           channel_id = factor(channel_id),
           video_id = factor(video_id),
           source = factor(source),
           metric = factor(metric)) %>%
    select(source, metric, channel_type, channel_id, channel_name, video_id, value, similarity) %>%
    arrange(source, metric, channel_type, channel_name, video_id)

df_cor <- df_all %>%
    group_by(source, metric, channel_type) %>%
    do(tidy(cor.test(.$value, .$similarity, method="pearson"))) %>%
    ungroup() %>%
    mutate(correlation = estimate) %>%
    select(source, metric, channel_type, correlation, p.value) 

df_cor %>% filter(source != "stats") %>%
    mutate(channel_type = fct_recode(channel_type, "right-w." = "right-wing", "basel." = "baseline")) %>%
    ggplot(aes(x=channel_type, y=metric, fill=correlation)) +
        facet_grid(~ source) +
        geom_tile() +
        geom_text(aes(label=sprintf("%.2f", correlation), color = p.value < 0.05)) +
        scale_x_discrete("Channel") +
        scale_y_discrete("Lexical Category") +
        scale_fill_gradient2(limits=c(-1, 1)) +
        scale_color_manual(values=c("black", "green"), guide=FALSE) +
        theme(legend.position="top")
ggsave("lexcatB-byvideo-cortable.pdf", width=4, height=12)

df_all %>%
    filter(source == "stats") %>%
    filter(metric %in% c("view_count", "comment_count",
                         "like_prop", "video_duration")) %>%
ggplot(aes(x=similarity, y=value)) +
    facet_wrap(channel_type ~ metric, scales="free", nrow=2) +
    geom_point() +
    geom_smooth(method="lm", se=FALSE) +
    geom_text(aes(label=channel_name), check_overlap=TRUE, vjust = 0) +
    geom_text(data=df_cor %>% filter(metric %in% c("view_count", "comment_count", 
                                                   "like_prop", "video_duration")) %>%
                              filter(p.value < 0.05),
              aes(label=sprintf("cor = %.2f", correlation)), 
              x=Inf, y=Inf, hjust=1, vjust=1, color="blue")
ggsave("lexcatB-byvideo-videostats-correlation.pdf", width=12, height=5)


