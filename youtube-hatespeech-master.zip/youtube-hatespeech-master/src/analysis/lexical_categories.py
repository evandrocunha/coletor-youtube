#!/usr/bin/env python3

import re
import html
import json
import csv
import collections

import nltk
lemmatizer = nltk.stem.WordNetLemmatizer()

def lemmatize_text(text):
    return " ".join( lemmatizer.lemmatize(word.lower(), "v") 
                         for word in re.findall("\w+", text) )

import empath
lexicon = empath.Empath()

DIR_BASE = "../.."

with open("{}/data/videos-filtered.jsonl".format(DIR_BASE), "r") as infile, \
     open("{}/info/lexcat/videos.tsv".format(DIR_BASE), "w") as outfile:

    headers = ["channel_type", "channel_id", "video_id"] + [ "lexcat_{}".format(cat) for cat in sorted(lexicon.cats.keys()) ]
    csvw = csv.DictWriter(outfile, fieldnames=headers, delimiter="\t")
    csvw.writeheader()

    for line in infile:
        obj = json.loads(line)

        lexcat = lexicon.analyze(lemmatize_text(obj["transcript"]))

        output = {"channel_type" : obj["channel_type"],
                  "channel_id"   : obj["channel_id"],
                  "video_id"     : obj["video_id"] }
        output.update({ "lexcat_{}".format(cat) : int(value) for cat, value in lexcat.items() })

        csvw.writerow(output)


with open("{}/data/comments-filtered.jsonl".format(DIR_BASE), "r") as infile, \
     open("{}/info/lexcat/comments.tsv".format(DIR_BASE), "w") as outfile, \
     open("{}/info/lexcat/comments-by_video.tsv".format(DIR_BASE), "w") as outfile_byvideo:

    headers = ["channel_type", "channel_id", "video_id"] + [ "lexcat_{}".format(cat) for cat in sorted(lexicon.cats.keys()) ]

    csvw = csv.DictWriter(outfile, fieldnames=headers, delimiter="\t")
    csvw.writeheader()

    csvw_byvideo = csv.DictWriter(outfile_byvideo, fieldnames=headers, delimiter="\t")
    csvw_byvideo.writeheader()

    actual_type, actual_channel, actual_video = None, None, None
    actual_counter = None

    for line in infile:
        obj = json.loads(line)

        lexcat = lexicon.analyze(lemmatize_text(obj["comment_text"]))

        lexcat_dict = { "lexcat_{}".format(cat) : int(value) for cat, value in lexcat.items() }

        output = {"channel_type" : obj["channel_type"],
                  "channel_id"   : obj["channel_id"],
                  "video_id"     : obj["video_id"] }
        output.update(lexcat_dict)

        csvw.writerow(output)

        if obj["video_id"] != actual_video:

            if actual_video is not None:

                output = {"channel_type" : actual_type,
                          "channel_id"   : actual_channel,
                          "video_id"     : actual_video }
                output.update(actual_counter)

                csvw_byvideo.writerow(output)
            
            actual_type, actual_channel, actual_video = obj["channel_type"], obj["channel_id"], obj["video_id"]
            actual_counter = collections.Counter()

        actual_counter.update(lexcat_dict)

    output = {"channel_type" : actual_type,
              "channel_id"   : actual_channel,
              "video_id"     : actual_video }
    output.update(actual_counter)

    csvw_byvideo.writerow(output)

